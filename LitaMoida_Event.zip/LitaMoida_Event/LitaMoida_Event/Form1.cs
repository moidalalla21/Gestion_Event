﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LitaMoida_Event
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=BANE_PC\SQLEXPRESS;Initial Catalog=Event;Integrated Security=True");
            con.Open();
            SqlCommand command = new SqlCommand("INSERT INTO TableEvent Values('" + int.Parse(textBox1.Text) + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "', getdate()", con);
            command.ExecuteNonQuery();
            MessageBox.Show("Inserer avec Succes");
            con.Close();
        }
    }
}
